package com.example.introapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
